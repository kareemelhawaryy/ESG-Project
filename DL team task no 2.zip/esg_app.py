import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout, LSTM, GRU, Flatten
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import warnings
warnings.filterwarnings("ignore")

# Page configuration
st.set_page_config(
    page_title="ESG Risk Assessment Tool",
    page_icon="🌱",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        color: #2E8B57;
        text-align: center;
        margin-bottom: 2rem;
    }
    .section-header {
        font-size: 1.5rem;
        color: #4682B4;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .metric-container {
        background-color: #f0f8ff;
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
    .risk-high {
        background-color: #ffebee;
        border-left: 5px solid #f44336;
        padding: 1rem;
        margin: 1rem 0;
    }
    .risk-medium {
        background-color: #fff3e0;
        border-left: 5px solid #ff9800;
        padding: 1rem;
        margin: 1rem 0;
    }
    .risk-low {
        background-color: #e8f5e8;
        border-left: 5px solid #4caf50;
        padding: 1rem;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'models_loaded' not in st.session_state:
    st.session_state.models_loaded = False
if 'scaler' not in st.session_state:
    st.session_state.scaler = None

# Title
st.markdown('<h1 class="main-header">🤖 AI-Enhanced ESG Auditor</h1>', unsafe_allow_html=True)

# Sidebar for navigation
st.sidebar.title("📊 Navigation")
page = st.sidebar.selectbox("Choose a page:", ["Home", "ESG Prediction", "Sentiment Analysis", "Model Training", "About"])

# Helper functions
@st.cache_data
def load_sample_data():
    """Load or generate sample ESG data for demonstration"""
    # This would normally load your actual dataset
    # For demo purposes, creating sample data
    np.random.seed(42)
    n_samples = 1000
    
    data = pd.DataFrame({
        'ESG_Environmental': np.random.uniform(10, 90, n_samples),
        'ESG_Social': np.random.uniform(10, 90, n_samples),
        'ESG_Governance': np.random.uniform(10, 90, n_samples),
        'CarbonEmissions': np.random.uniform(100, 2000, n_samples),
        'WaterUsage': np.random.uniform(50, 500, n_samples),
        'EnergyConsumption': np.random.uniform(500, 5000, n_samples),
        'Year': np.random.choice(range(2015, 2024), n_samples),
        'Industry': np.random.choice(['Technology', 'Manufacturing', 'Finance', 'Healthcare', 'Energy'], n_samples)
    })
    
    # Calculate overall ESG score
    data['ESG_Overall'] = (data['ESG_Environmental'] + data['ESG_Social'] + data['ESG_Governance']) / 3
    
    return data

def create_sequences(data, feature_cols, target_col, seq_len=5):
    """Create sequences for LSTM model"""
    X, y = [], []
    for i in range(len(data) - seq_len):
        X.append(data[feature_cols].iloc[i:i+seq_len].values)
        y.append(data[target_col].iloc[i+seq_len])
    return np.array(X), np.array(y)

def train_models(data):
    """Train both LSTM and Dense models"""
    with st.spinner("Training models... This may take a few minutes."):
        # Prepare data
        features = ['ESG_Environmental', 'ESG_Social', 'ESG_Governance',
                   'CarbonEmissions', 'WaterUsage', 'EnergyConsumption']
        target = 'ESG_Overall'
        
        # Encode categorical variables
        le = LabelEncoder()
        data['Industry'] = le.fit_transform(data['Industry'])
        
        # Scale features
        scaler = MinMaxScaler()
        data_scaled = pd.DataFrame(scaler.fit_transform(data[features]), columns=features)
        data_scaled['ESG_Overall'] = data['ESG_Overall']
        
        # Create sequences
        X, y = create_sequences(data_scaled, features, target, seq_len=5)
        input_shape = (X.shape[1], X.shape[2])
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # LSTM Model
        model_lstm = Sequential([
            LSTM(64, return_sequences=True, input_shape=input_shape),
            Dropout(0.2),
            LSTM(32),
            Dropout(0.2),
            Dense(16, activation='relu'),
            Dropout(0.2),
            Dense(1)
        ])
        
        model_lstm.compile(optimizer=Adam(0.001), loss='mse', metrics=['mae'])
        model_lstm.fit(X_train, y_train, epochs=20, batch_size=32, validation_split=0.2, verbose=0)
        
        # Dense Model
        X_dense = X.reshape((X.shape[0], -1))
        X_train_d, X_test_d, y_train_d, y_test_d = train_test_split(X_dense, y, test_size=0.2, random_state=42)
        
        model_dense = Sequential([
            Dense(128, activation='relu', input_shape=(X_train_d.shape[1],)),
            Dropout(0.3),
            Dense(64, activation='relu'),
            Dropout(0.3),
            Dense(1)
        ])
        
        model_dense.compile(optimizer=Adam(0.001), loss='mse', metrics=['mae'])
        model_dense.fit(X_train_d, y_train_d, epochs=20, batch_size=32, validation_split=0.2, verbose=0)
        
        # Evaluate models
        y_pred_lstm = model_lstm.predict(X_test)
        y_pred_dense = model_dense.predict(X_test_d)
        
        mae_lstm = mean_absolute_error(y_test, y_pred_lstm)
        mae_dense = mean_absolute_error(y_test_d, y_pred_dense)
        
        return model_lstm, model_dense, scaler, mae_lstm, mae_dense

def predict_esg_score(user_input, model_lstm, model_dense, scaler):
    """Predict ESG score from user input"""
    features = ['ESG_Environmental', 'ESG_Social', 'ESG_Governance',
               'CarbonEmissions', 'WaterUsage', 'EnergyConsumption']
    
    user_df = pd.DataFrame([user_input])[features]
    scaled_input = scaler.transform(user_df)
    
    # LSTM prediction
    seq_lstm = np.array([scaled_input for _ in range(5)])
    seq_lstm = seq_lstm.reshape((1, 5, len(features)))
    pred_lstm = model_lstm.predict(seq_lstm)[0][0]
    
    # Dense prediction
    seq_dense = scaled_input.flatten().reshape(1, -1).repeat(5, axis=0).flatten().reshape(1, -1)
    pred_dense = model_dense.predict(seq_dense)[0][0]
    
    # Average prediction
    final_pred = (pred_lstm + pred_dense) / 2
    
    return final_pred, pred_lstm, pred_dense

def get_risk_assessment(score):
    """Get risk level and insights based on ESG score"""
    if score < 40:
        return "High Risk", "🚨 Urgent ESG Action Needed", "risk-high"
    elif score < 60:
        return "Medium Risk", "⚠️ Monitor and Improve ESG Policies", "risk-medium"
    else:
        return "Low Risk", "✅ Satisfactory ESG Performance", "risk-low"

# Page routing
if page == "Home":
    st.markdown('<h2 class="section-header">Risk Prediction & Sentiment Analysis</h2>', unsafe_allow_html=True)
    
    st.markdown("""
    This tool helps you assess Environmental, Social, and Governance (ESG) risks for companies using machine learning models.
    
    **Features:**
    - 🔮 **ESG Score Prediction**: Get predictions using LSTM and Dense Neural Network models
    - 📊 **Risk Assessment**: Automatic risk categorization and insights
    - 💭 **Sentiment Analysis**: Analyze ESG-related text sentiment
    - 📈 **Model Training**: Train models on your own data
    
    **How to use:**
    1. Navigate to "ESG Prediction" to input company data and get risk assessments
    2. Use "Sentiment Analysis" to analyze ESG-related news or reports
    3. Train models with your own data in the "Model Training" section
    """)
    
    # Display sample statistics
    data = load_sample_data()
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Companies", len(data))
    with col2:
        st.metric("Avg ESG Score", f"{data['ESG_Overall'].mean():.1f}")
    with col3:
        st.metric("Industries", data['Industry'].nunique())
    with col4:
        st.metric("Years Covered", f"{data['Year'].min()}-{data['Year'].max()}")

elif page == "ESG Prediction":
    st.markdown('<h2 class="section-header">🔮 ESG Score Prediction</h2>', unsafe_allow_html=True)
    
    # Load or train models
    if not st.session_state.models_loaded:
        st.info("Models need to be trained first. Click the button below to train models with sample data.")
        if st.button("Train Models"):
            data = load_sample_data()
            model_lstm, model_dense, scaler, mae_lstm, mae_dense = train_models(data)
            st.session_state.model_lstm = model_lstm
            st.session_state.model_dense = model_dense
            st.session_state.scaler = scaler
            st.session_state.models_loaded = True
            st.success(f"Models trained successfully! LSTM MAE: {mae_lstm:.3f}, Dense MAE: {mae_dense:.3f}")
            st.rerun()
    
    if st.session_state.models_loaded:
        st.success("Models are ready for prediction!")
        
        # User input form
        st.markdown("### Enter Company ESG Data:")
        
        col1, col2 = st.columns(2)
        
        with col1:
            esg_env = st.slider("Environmental Score", 0, 100, 50, help="Environmental performance score")
            esg_social = st.slider("Social Score", 0, 100, 50, help="Social responsibility score")
            esg_gov = st.slider("Governance Score", 0, 100, 50, help="Corporate governance score")
        
        with col2:
            carbon_emissions = st.number_input("Carbon Emissions (tons)", 0, 5000, 1000, help="Annual carbon emissions")
            water_usage = st.number_input("Water Usage (cubic meters)", 0, 1000, 200, help="Annual water consumption")
            energy_consumption = st.number_input("Energy Consumption (MWh)", 0, 10000, 2000, help="Annual energy consumption")
        
        if st.button("Predict ESG Risk", type="primary"):
            user_input = {
                'ESG_Environmental': esg_env,
                'ESG_Social': esg_social,
                'ESG_Governance': esg_gov,
                'CarbonEmissions': carbon_emissions,
                'WaterUsage': water_usage,
                'EnergyConsumption': energy_consumption
            }
            
            # Make prediction
            final_pred, pred_lstm, pred_dense = predict_esg_score(
                user_input, 
                st.session_state.model_lstm, 
                st.session_state.model_dense, 
                st.session_state.scaler
            )
            
            # Get risk assessment
            risk_level, insight, risk_class = get_risk_assessment(final_pred)
            
            # Display results
            st.markdown("### 📊 Prediction Results")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Overall ESG Score", f"{final_pred:.1f}")
            with col2:
                st.metric("LSTM Prediction", f"{pred_lstm:.1f}")
            with col3:
                st.metric("Dense NN Prediction", f"{pred_dense:.1f}")
            
            # Risk assessment display
            st.markdown(f"""
            <div class="{risk_class}">
                <h3>Risk Level: {risk_level}</h3>
                <p>{insight}</p>
            </div>
            """, unsafe_allow_html=True)
            
            # Recommendations
            st.markdown("### 💡 Recommendations")
            if final_pred < 40:
                st.error("**Immediate Action Required:**")
                st.markdown("- Develop comprehensive ESG improvement plan")
                st.markdown("- Reduce carbon emissions and resource consumption")
                st.markdown("- Strengthen governance policies")
            elif final_pred < 60:
                st.warning("**Areas for Improvement:**")
                st.markdown("- Monitor ESG performance regularly")
                st.markdown("- Set measurable sustainability targets")
                st.markdown("- Enhance stakeholder engagement")
            else:
                st.success("**Maintain Excellence:**")
                st.markdown("- Continue current ESG practices")
                st.markdown("- Share best practices with industry")
                st.markdown("- Set ambitious long-term goals")

elif page == "Sentiment Analysis":
    st.markdown('<h2 class="section-header">💭 ESG Sentiment Analysis</h2>', unsafe_allow_html=True)
    
    # Download NLTK data if needed
    try:
        nltk.data.find('vader_lexicon')
    except LookupError:
        with st.spinner("Downloading sentiment analysis models..."):
            nltk.download('vader_lexicon')
    
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    sid = SentimentIntensityAnalyzer()
    
    st.markdown("Analyze the sentiment of ESG-related text (news articles, reports, etc.)")
    
    # Text input
    text_input = st.text_area(
        "Enter ESG-related text:", 
        placeholder="e.g., 'Company received award for sustainable practices and environmental leadership.'",
        height=150
    )
    
    if st.button("Analyze Sentiment"):
        if text_input:
            scores = sid.polarity_scores(text_input)
            
            # Display results
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Positive", f"{scores['pos']:.3f}")
            with col2:
                st.metric("Neutral", f"{scores['neu']:.3f}")
            with col3:
                st.metric("Negative", f"{scores['neg']:.3f}")
            with col4:
                st.metric("Compound", f"{scores['compound']:.3f}")
            
            # Interpretation
            compound = scores['compound']
            if compound >= 0.05:
                sentiment = "Positive 😊"
                color = "green"
            elif compound <= -0.05:
                sentiment = "Negative 😞"
                color = "red"
            else:
                sentiment = "Neutral 😐"
                color = "gray"
            
            st.markdown(f"**Overall Sentiment:** <span style='color: {color}'>{sentiment}</span>", unsafe_allow_html=True)
        else:
            st.warning("Please enter some text to analyze.")
    
    # Sample texts for demonstration
    st.markdown("### 🔍 Try These Examples:")
    examples = [
        "Company fined for illegal waste dumping and environmental violations.",
        "Strong commitment to employee wellbeing and diversity initiatives.",
        "Unfair labor practices discovered in overseas manufacturing plant.",
        "Received ESG excellence award for sustainable business practices.",
        "Board lacks diversity and transparency in decision-making processes."
    ]
    
    for i, example in enumerate(examples):
        if st.button(f"Example {i+1}: {example[:50]}..."):
            st.text_area("Selected text:", value=example, key=f"example_{i}")

elif page == "Model Training":
    st.markdown('<h2 class="section-header">📈 Model Training</h2>', unsafe_allow_html=True)
    
    st.markdown("Train ESG prediction models with your own data or sample data.")
    
    # File upload option
    st.markdown("### Upload Your Data")
    uploaded_file = st.file_uploader("Upload CSV file", type=['csv'])
    
    if uploaded_file is not None:
        data = pd.read_csv(uploaded_file)
        st.success("Data uploaded successfully!")
        st.dataframe(data.head())
    else:
        st.info("No file uploaded. Using sample data for training.")
        data = load_sample_data()
        st.dataframe(data.head())
    
    # Training configuration
    st.markdown("### Training Configuration")
    col1, col2 = st.columns(2)
    
    with col1:
        epochs = st.slider("Number of Epochs", 10, 100, 30)
        batch_size = st.selectbox("Batch Size", [16, 32, 64, 128], index=1)
    
    with col2:
        test_size = st.slider("Test Set Size", 0.1, 0.5, 0.2)
        sequence_length = st.slider("Sequence Length", 3, 10, 5)
    
    if st.button("Start Training", type="primary"):
        # Modified training function to accept parameters
        with st.spinner("Training models... This may take a few minutes."):
            try:
                # Prepare data
                features = ['ESG_Environmental', 'ESG_Social', 'ESG_Governance',
                           'CarbonEmissions', 'WaterUsage', 'EnergyConsumption']
                target = 'ESG_Overall'
                
                # Check if required columns exist
                missing_cols = [col for col in features + [target] if col not in data.columns]
                if missing_cols:
                    st.error(f"Missing required columns: {missing_cols}")
                    st.stop()
                
                # Encode categorical variables if Industry exists
                if 'Industry' in data.columns:
                    le = LabelEncoder()
                    data['Industry'] = le.fit_transform(data['Industry'])
                
                # Scale features
                scaler = MinMaxScaler()
                data_scaled = pd.DataFrame(scaler.fit_transform(data[features]), columns=features)
                data_scaled['ESG_Overall'] = data['ESG_Overall']
                
                # Create sequences
                X, y = create_sequences(data_scaled, features, target, seq_len=sequence_length)
                input_shape = (X.shape[1], X.shape[2])
                
                # Split data
                X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)
                
                # Progress bar
                progress_bar = st.progress(0)
                
                # LSTM Model
                model_lstm = Sequential([
                    LSTM(64, return_sequences=True, input_shape=input_shape),
                    Dropout(0.2),
                    LSTM(32),
                    Dropout(0.2),
                    Dense(16, activation='relu'),
                    Dropout(0.2),
                    Dense(1)
                ])
                
                model_lstm.compile(optimizer=Adam(0.001), loss='mse', metrics=['mae'])
                progress_bar.progress(25)
                
                model_lstm.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=0.2, verbose=0)
                progress_bar.progress(50)
                
                # Dense Model
                X_dense = X.reshape((X.shape[0], -1))
                X_train_d, X_test_d, y_train_d, y_test_d = train_test_split(X_dense, y, test_size=test_size, random_state=42)
                
                model_dense = Sequential([
                    Dense(128, activation='relu', input_shape=(X_train_d.shape[1],)),
                    Dropout(0.3),
                    Dense(64, activation='relu'),
                    Dropout(0.3),
                    Dense(1)
                ])
                
                model_dense.compile(optimizer=Adam(0.001), loss='mse', metrics=['mae'])
                progress_bar.progress(75)
                
                model_dense.fit(X_train_d, y_train_d, epochs=epochs, batch_size=batch_size, validation_split=0.2, verbose=0)
                progress_bar.progress(100)
                
                # Evaluate models
                y_pred_lstm = model_lstm.predict(X_test)
                y_pred_dense = model_dense.predict(X_test_d)
                
                mae_lstm = mean_absolute_error(y_test, y_pred_lstm)
                mae_dense = mean_absolute_error(y_test_d, y_pred_dense)
                rmse_lstm = np.sqrt(mean_squared_error(y_test, y_pred_lstm))
                rmse_dense = np.sqrt(mean_squared_error(y_test_d, y_pred_dense))
                
                # Store models in session state
                st.session_state.model_lstm = model_lstm
                st.session_state.model_dense = model_dense
                st.session_state.scaler = scaler
                st.session_state.models_loaded = True
                
                # Display results
                st.success("Training completed successfully!")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("**LSTM Model Performance:**")
                    st.metric("MAE", f"{mae_lstm:.3f}")
                    st.metric("RMSE", f"{rmse_lstm:.3f}")
                
                with col2:
                    st.markdown("**Dense NN Model Performance:**")
                    st.metric("MAE", f"{mae_dense:.3f}")
                    st.metric("RMSE", f"{rmse_dense:.3f}")
                
                # Visualization
                fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
                
                # LSTM predictions
                ax1.scatter(y_test, y_pred_lstm, alpha=0.7)
                ax1.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
                ax1.set_xlabel('Actual ESG Score')
                ax1.set_ylabel('Predicted ESG Score')
                ax1.set_title('LSTM Model Predictions')
                ax1.grid(True, alpha=0.3)
                
                # Dense predictions
                ax2.scatter(y_test_d, y_pred_dense, alpha=0.7)
                ax2.plot([y_test_d.min(), y_test_d.max()], [y_test_d.min(), y_test_d.max()], 'r--', lw=2)
                ax2.set_xlabel('Actual ESG Score')
                ax2.set_ylabel('Predicted ESG Score')
                ax2.set_title('Dense NN Model Predictions')
                ax2.grid(True, alpha=0.3)
                
                plt.tight_layout()
                st.pyplot(fig)
                
            except Exception as e:
                st.error(f"Training failed: {str(e)}")

elif page == "About":
    st.markdown('<h2 class="section-header">ℹ️ About This Tool</h2>', unsafe_allow_html=True)
    
    st.markdown("""
    ### 🎯 Purpose
    This ESG Risk Assessment Tool helps organizations evaluate their Environmental, Social, and Governance performance 
    using advanced machine learning techniques.
    
    ### 🔧 Technology Stack
    - **Frontend**: Streamlit
    - **Machine Learning**: TensorFlow/Keras
    - **Models**: LSTM (Long Short-Term Memory) and Dense Neural Networks
    - **Sentiment Analysis**: NLTK VADER
    - **Data Processing**: Pandas, NumPy, Scikit-learn
    
    ### 📊 Models
    
    **LSTM Model:**
    - Captures temporal patterns in ESG data
    - Uses sequence-based learning for better prediction accuracy
    - Ideal for time-series ESG performance analysis
    
    **Dense Neural Network:**
    - Processes all features simultaneously
    - Provides rapid predictions
    - Good for cross-sectional analysis
    
    ### 📈 Features
    - **ESG Score Prediction**: Predicts overall ESG performance
    - **Risk Assessment**: Categorizes companies into risk levels
    - **Sentiment Analysis**: Analyzes ESG-related text sentiment
    - **Model Training**: Custom model training with your data
    
    ### 🎯 Use Cases
    - Investment decision making
    - ESG compliance monitoring
    - Risk management
    - Sustainability reporting
    - Stakeholder communication
    
    ### 📋 Data Requirements
    The tool requires the following data fields:
    - ESG_Environmental: Environmental performance score (0-100)
    - ESG_Social: Social responsibility score (0-100)
    - ESG_Governance: Corporate governance score (0-100)
    - CarbonEmissions: Annual carbon emissions (tons)
    - WaterUsage: Annual water consumption (cubic meters)
    - EnergyConsumption: Annual energy consumption (MWh)
    
    ### ⚠️ Disclaimer
    This tool is for educational and research purposes. ESG assessments should be complemented with 
    comprehensive due diligence and professional advice for investment decisions.
    """)
    
    st.markdown("---")
    st.markdown("**Version:** 1.0 | **Last Updated:** July 2025")

# Footer
st.markdown("---")
st.markdown("*Built with ❤️ using Streamlit and TensorFlow*")